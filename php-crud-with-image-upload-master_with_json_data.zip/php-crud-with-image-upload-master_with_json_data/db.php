<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "php-crud-with-image-upload-master";

$conn = mysqli_connect($host, $username, $password, $dbname);
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}

?>
